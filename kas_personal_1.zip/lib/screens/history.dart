import 'package:flutter/material.dart';
import 'package:kas_personal/models/kas.dart';
import 'package:kas_personal/providers/kas_provider.dart';
import 'package:kas_personal/widgets/kas_item.dart';
import 'package:provider/provider.dart';

class KasHistoryScreen extends StatelessWidget {
  const KasHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('History Transaksi'),
      ),
      body: Consumer<KasProvider>(
        builder: (context, provider, child) {
          final allItems = provider.allItems;
          return ListView.separated(
            itemCount: allItems.length,
            separatorBuilder: (context, index) => Divider(
              height: 0,
              color: Colors.grey.shade200,
            ),
            itemBuilder: (context, index) {
              var kas = allItems[index];
              return KasItem(
                kas: kas,
                onTap: () => _onItemTap(context, kas),
              );
            },
          );
        },
      ),
    );
  }

  void _onItemTap(BuildContext context, Kas kas) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus'),
        content: const Text('Anda yakin ingin menghapus transaksi ini?'),
        actions: [
          ElevatedButton(
            onPressed: () {
              Provider.of<KasProvider>(context, listen: false).hapus(kas);
              Navigator.of(context).pop();
            },
            child: const Text('Ya'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Tidak'),
          ),
        ],
      ),
    );
  }
}
